//
//  AppDelegate.h
//  练习Demo
//
//  Created by peter on 2019/1/11.
//  Copyright © 2019年 peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

